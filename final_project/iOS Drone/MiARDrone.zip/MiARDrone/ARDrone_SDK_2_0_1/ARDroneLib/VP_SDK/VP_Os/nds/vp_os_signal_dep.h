/**
 * @file vp_os_signal_dep.h
 * @author aurelien.morelle@parrot.fr
 * @date 2006/12/15
 */

#ifndef _SIGNAL_INCLUDE_OS_DEP_
#define _SIGNAL_INCLUDE_OS_DEP_


typedef void *vp_os_mutex_t;

typedef void *vp_os_cond_t;


#endif // ! _SIGNAL_INCLUDE_OS_DEP_

